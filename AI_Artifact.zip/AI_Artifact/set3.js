window.onload = init();
function init() {

c=document.getElementById("canvas101")
ctx=c.getContext("2d");

//audio clips
var audio5 = new Audio('busted.mp3');
audio5.volume = 0.8;

var audio3=new Audio('freeze.mp3');
audio3.volume=0.10;

var audio7=new Audio('heli.mp3');
audio7.volume=0.10;


//initiating thinking bubble 
var dialogue1=new Image();
dialogue1.src="thinking.png";

//dialogue box
var dialogue1=new Image();
dialogue1.src="thinking.png";	

//police dog
var dogx=20;
var dogy=370;

//thief position
var thiefx=20;
var thiefy=370;

//heli position
var helix=20;
var heliy=10;
var SPEED = 1;

//initializing 
youCanSee=true;

function thief () {
ctx.canvas.width  = window.innerWidth;
ctx.canvas.height = window.innerHeight;
var thiefImg= new Image();
if (65 in keyPress){
thiefImg.src="gent.png";
youCanSee=false;}
else{
    thiefImg.src="thief.png";}
ctx.drawImage (thiefImg, thiefx, thiefy) ; } //draw thief

Infarred = false; 

function caught () { //function if thief is caught
if ((youCanSee==true) && (bx1<thiefx) && (bx2>thiefx )) {
    Infarred=true;
    audio5.play();
    audio3.play();}}
 

//bottom light 
var bx1= 40 ;
var bx2= 260 ;


function thinking (){
	if ((thiefx>=24) && (thiefx<=150)) {
     ctx.drawImage (dialogue1, thiefx + 22, thiefy-55) ;   
    }
    
}

 

function Heli () {
var heliImg= new Image();
heliImg.src='heli.png';
ctx.drawImage (heliImg, helix, heliy);}


function draw()  {
ctx.beginPath();
ctx.fill(); 
if (Infarred== true) { 
    ctx.fillStyle ='rgba(255, 0, 0, 0.4)'    
} else {
 ctx.fillStyle ='rgba(255, 255, 0, 0.4)'   
}
ctx.moveTo(helix+200,heliy+80);
ctx.lineTo(bx1,550);
ctx.lineTo(bx2,550);

ctx.fill(); }



function coordinatF() {
var   z = Math.random() * 50; // random number between 0 and 100
if (z>10)
helix = helix + 0.5 + SPEED;
bx1=bx1+SPEED;
bx2=bx2+SPEED;} // heli and light move forward



var keyPress={};
	
addEventListener("keydown",function(e){
keyPress[e.keyCode]=true;},false);
 
addEventListener("keyup",function(e){
	 delete keyPress[e.keyCode];},false);
	 
function update(){
	 if(37 in keyPress){
		 thiefx = thiefx - 10; 
	 }
	 
	 if(39 in keyPress) {
		 thiefx = thiefx + 10;}}


function nextWindow(){
 if  (helix >1200) // end of part2
    window.open("set4.html", "_self"); }


function Loop()
{
	thief();
    caught();
    coordinatF();
    Heli();
    draw();
    thinking();
    update();
    nextWindow();
    audio7.play();
    setTimeout(Loop, 20);  
}  
Loop(); 
}

