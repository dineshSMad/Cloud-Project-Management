window.onload = init();
function init() {

c=document.getElementById("canvas10")
ctx=c.getContext("2d");


//audio clips
var audio5 = new Audio('busted.mp3');
audio5.volume = 0.8;

var audio2=new Audio('police.mp3');
audio2.volume = 0.01;

var audio3=new Audio('freeze.mp3');
audio3.volume=0.10;

var audio6 = new Audio('breath.mp3');
audio6.volume=0.5;


//initiating Thinking Bubble 
var dialogue1=new Image();
dialogue1.src="thiefmove.png";	

//initiating dialogue 01
var dialogue2=new Image();
dialogue2.src="child1.png";

//initializing police see
policeSee=false;

//thief position
var thiefx=202;
var thiefy=370;


//torch man position
var torchx=360;
var torchy=230;


//circle start
var  x1 = 900 ; 
var  y1 = 310; 
var SPEED = 1;
 

//police position
var policeCarx=20;
var poiceCary=200;
var SPEED = 1;
var carImg= new Image();
carImg.src="policecar.png" ;

//initializing time count
timeCount=0;

function thief () {
ctx.canvas.width  = window.innerWidth;
ctx.canvas.height = window.innerHeight;
var thiefImg= new Image();
if ((policeSee==true) &&  (thiefx<1000)){
thiefImg.src="thief.png" ;
}else{
    thiefImg.src="thiefC.png"}
ctx.drawImage (thiefImg, thiefx, thiefy) ; } //draw thief


function thinking (){
	if (thiefx<350){
	ctx.drawImage(dialogue1,thiefx+25,thiefy-55);}//draw dialougue 
  }

function torch () {
var torchImg= new Image();
torchImg.src="torch.png" ;
ctx.drawImage (torchImg, torchx, torchy); }
 

function draw()  {
ctx.beginPath();
if (policeSee==false) {
ctx.arc (x1, y1, 100 , 0 , 6 , false); 
}else {
  ctx.arc (thiefx+100, thiefy+90, 100 , 0 , 6 , false)}

ctx.fillStyle ='rgba(255, 255, 0, 0.5)';
ctx.fill(); }

function circleTime () {     //move circle 
   x1 = x1 + 1+ SPEED;         
   y1=y1+SPEED; }              



function check() {
  var   z = Math.random() * 50; // random number between 0 and 100
  if (z>10) {
   policeCarx = policeCarx + SPEED;
   thiefx=thiefx+SPEED;} // move forward

if (13 in keyPress){  // Enter key press
  policeSee=true;}
  
if (policeSee == true) {
      SPEED=0; } // stop moving forward

if ((SPEED==0) && (thiefx<1000)){
  ctx.drawImage(dialogue2,torchx +25,torchy-55);//draw dialougue2 
    audio3.play();//play audio
    audio5.play();} }  //end if caught

function tone(){
if (timeCount<1000) {
   audio2.play();
    audio6.play(); }
  if ((timeCount<1000) && (SPEED==0)) {
    audio6.pause();
  }}

var keyPress = {} ;   // initialize  key presses
 addEventListener("keydown", 
 function (e)   {
 keyPress[e.keyCode] = true;    }   , false);
 addEventListener("keyup", 
 function (e)    {
   delete keyPress[e.keyCode];
  }  , false);


function policecar () {
ctx.drawImage (carImg, policeCarx-150, poiceCary) ; } //drawing police car


function nextWindow(){
	if  ((thiefx>1000) && (policeSee==false)) // end of part2
	window.open("set3.html", "_self"); }


function Loop()
	{  
		console.log("Hello2");
		thief();
    torch();
    check();
    draw(); 
    thinking();
    circleTime();
    nextWindow();
    tone()
      timeCount=timeCount+1;
    policecar();
		setTimeout(Loop, 20);  
	}  
	Loop()

     }