window.onload = init();
function init() {
c=document.getElementById("canvas3")
ctx=c.getContext("2d");


//thief1 position 
 var thiefx=20;
 var thiefy=370;

//audio  files
var audio1 = new Audio('gunSound.mp3');
audio1.volume = 0.8;

var audio2=new Audio('police.mp3');
audio2.volume = 0.01;

var audio3=new Audio('freeze.mp3');
audio3.volume=0.10;

var audio4=new Audio('alarm.mp3');
audio4.volume=0.10;

var audio5 = new Audio('busted.mp3');
audio5.volume = 0.8;


//Drawing speech Bubbles 
var dialogue1=new Image();
dialogue1.src="speech1.png";	

var dialogue2=new Image();
dialogue2.src="speech2.png";

var dialogue3=new Image();
dialogue3.src="speech3.png";


//thief2 position
var thief2x=05;
var thief2y=350;

//police position
var policex=900;
var policey=320;

 //thief function
function thief2 (){
var thief2Img= new Image();
thief2Img.src="thief2.png" ;
ctx.drawImage (thief2Img, thief2x, thief2y) ; }

//thief function
function thief (){
var thiefImg= new Image();
thiefImg.src="thief.png" ;
ctx.drawImage (thiefImg, thiefx, thiefy) ; }

//initialize time of day
timeofday = "Day Time";
hourcount= 0;

function bankAlarm() {
if (hourcount< 500)
audio4.play();}

function sunormoon() {	
       if (hourcount==500) //about 20 seconds
           timeofday = "Night Time";
		   
      if (hourcount==1000)// about 20 seconds
	timeofday= "Day Time"
        }


function dark() {
		   if (timeofday == "Night Time") {
			 ctx.fillStyle = 'rgba(0, 0, 0, 0.5)';
			ctx.rect(0,0,1700,1700);
			 ctx.fill();}
			if (timeofday == "Day Time") {
					ctx.fillStyle = "transparent";
				   ctx.rect(0,0,1249,349);
					ctx.fill();	} }

function see(){
	if ((thiefx>500) && (thiefx<900) && (timeofday == "Day Time")){
		 policeCanSee = true;
	}else{
		 policeCanSee = false;}}

		 
	
function shoot () {
	if (policeCanSee==true) //shootig based on the daytime and thief1 position 
	shootPlayer();
} 


//initialize conversation count
conversationCount=0;
function conversation (){
	if ((thiefx>150) && (conversationCount<=200) && (timeofday == "Day Time")){
	ctx.drawImage(dialogue1,thief2x+25,thief2y-55);}//displays first dialugue by thief2
	if (((thiefx>150) && (thiefx<490)) && (conversationCount>=350) && (timeofday == "Night Time")) {
		ctx.drawImage(dialogue3,thief2x+35,thief2y-40);}//displays third dialugue by thief1	
	if (((thiefx>150 ) &&(thiefx<490) ) && (conversationCount>300) && (timeofday == "Day Time")) {
		ctx.drawImage(dialogue2,thiefx+25,thiefy-55);}//displays third dialugue by thief1	
	}
	

function shootPlayer()
		{
		ctx.lineWidth = 5;
		ctx.strokeStyle = 'yellow';
		ctx.beginPath();
		ctx.moveTo(932,370);
		ctx.lineTo(thiefx,thiefy);
		ctx.stroke();
		ctx.moveTo(932,370);
		ctx.lineTo(thief2x,thief2y);
		ctx.stroke();
	    audio5.play ();
        audio3.play();
		audio1.play(); 
		audio2.play();  }


//police function
function police() {
var policeImg=new Image();
ctx.canvas.width  = window.innerWidth;
ctx.canvas.height = window.innerHeight;
policeShoot=false;

if ((thiefx>500) && (thiefx<900) && (timeofday == "Day Time")){
	policeShoot = true;}
	else{
	policeShoot = false;}

if ((thiefx>50) && (timeofday == "Night Time")){
	policePresent = false;}
	else{
	policePresent = true;}

if (policeShoot==true) {
policeImg.src="police2.png";
}if (policeShoot==false){
policeImg.src="police.png" 
} 
if (policePresent==false){
policeImg.src="";}
ctx.drawImage (policeImg, policex, policey); } 


var keyPress={};
	
 addEventListener("keydown",function(e){
 keyPress[e.keyCode]=true;},false);
 
 addEventListener("keyup",function(e){
	 delete keyPress[e.keyCode];},false);
	 
 function update(){
	 if(37 in keyPress){
		 thiefx = thiefx - 10; 
	 }
	 
	 if(39 in keyPress) {
		 thiefx = thiefx + 10;
	 }
 }

 function nextWindow(){
	if  ((thiefx>999) && (timeofday == "Night Time")) // end of the part1
	window.open("set2.html", "_self") }


 function Loop()
	{  
		console.log("Hello");
		update();
		police();
		thief();
		conversation();
		 conversationCount= conversationCount+1;
		sunormoon();
		 hourcount = hourcount+1;
		thief2();
		dark();
		see();
		shoot();
		bankAlarm();
	    nextWindow();
		setTimeout(Loop, 20);  
	}  
	Loop()
}
